Picante is a multi-colored theme written by Eric Arnol-Martin for EHCP Force Edition using proper HTML, CSS, and Javascript.  Feel free to modify and change any of my code.  If you have any comments or suggestions, by all means, please contact me by email.

Should Javascript be disabled in a user's browser, the theme should still load without errors.   It will default to the green theme by default.  

This theme has been extensively tested in Firefox and Internet Explorer only.  Download and install EHCP at http://ehcpforce.tk/

Author:  Eric Arnol-Martin
Email:	 earnolmartin@gmail.com
Date:	 8/14/2014

This wouldn't be possible without EHCP (http://ehcpforce.tk/), the best free hosting web control panel / web hosting package out on the net.  Thanks to EHCP!  Keep going strong!
