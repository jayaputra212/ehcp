THESE FILES REMOVED from Class-Inspector-1.25: 
inc/
MANIFEST
t/
META.yml
xt/
Makefile.PL


THESE FILES REMOVED from SOAP-Lite-0.712:
t/
examples/
bin/
META.yml
MANIFEST
Makefile.PL
